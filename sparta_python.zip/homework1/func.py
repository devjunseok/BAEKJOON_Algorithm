def add_func(num1, num2):
    print(num1 + num2)
    
def subtract_func(num1, num2):
    print(num1 - num2) 

def multiply_func(num1, num2):
    print(num1 * num2)
    
def divide_func(num1, num2):
    print(num1 / num2)

    
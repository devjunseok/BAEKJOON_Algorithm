def solve(a):
    return sum(a)
a = input()
a = str(a)
print(f'{a}??!')

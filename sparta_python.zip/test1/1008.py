a, b = map(float, input().split())
print(a/b)

